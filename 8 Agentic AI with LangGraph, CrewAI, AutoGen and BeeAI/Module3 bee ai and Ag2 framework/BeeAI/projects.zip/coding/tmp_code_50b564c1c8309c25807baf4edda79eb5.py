import numpy as np
import matplotlib.pyplot as plt

# Define the range of x from -2π to 2π
x = np.linspace(-2 * np.pi, 2 * np.pi, 1000)  # 1000 points for a smooth curve

# Compute the corresponding y values for the sine function
y = np.sin(x)

# Create the plot
plt.figure(figsize=(10, 5))  # Optional: adjust the figure size
plt.plot(x, y, label='sin(x)', color='blue')  # Plot sine wave

# Add labels and title
plt.title('Sine Wave')
plt.xlabel('x (radians)')
plt.ylabel('sin(x)')
plt.axhline(0, color='black',linewidth=0.5, ls='--')  # Add a horizontal line at y=0
plt.axvline(0, color='black',linewidth=0.5, ls='--')  # Add a vertical line at x=0
plt.grid(color = 'gray', linestyle = '--', linewidth = 0.5)  # Add grid
plt.legend()  # Add legend

# Save the plot as a PNG file
plt.savefig('sine_wave.png')

# Show the plot (optional)
plt.show()