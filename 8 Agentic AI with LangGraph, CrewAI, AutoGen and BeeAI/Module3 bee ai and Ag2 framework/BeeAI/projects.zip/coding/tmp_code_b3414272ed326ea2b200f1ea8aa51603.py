import matplotlib.pyplot as plt
import math

# Define the range of x from -2π to 2π
x = [i * 0.01 for i in range(-628, 629)]  # From -628 to 628 (includes -2π to 2π approximately)
y = [math.sin(i) for i in x]  # Calculate sine values

# Create the plot
plt.figure(figsize=(10, 5))
plt.plot(x, y, label='sin(x)', color='blue')

# Add labels and title
plt.title('Sine Wave')
plt.xlabel('x (radians)')
plt.ylabel('sin(x)')
plt.axhline(0, color='black', linewidth=0.5, ls='--')
plt.axvline(0, color='black', linewidth=0.5, ls='--')
plt.grid(color='gray', linestyle='--', linewidth=0.5)
plt.legend()

# Save the plot as a PNG file
plt.savefig('sine_wave.png')

# Show the plot (optional)
plt.show()