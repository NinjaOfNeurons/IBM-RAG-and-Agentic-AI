---

### Shopping Guide for Chicken Stir Fry (Serving 4)

**Budget:** $25

#### Ingredients & Quantity (Approximate Prices)